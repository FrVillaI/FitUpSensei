import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import { Home } from './screens/Home';
import { Explore } from './screens/Explore';
import { ExerciseDetail } from './screens/ExerciseDetail';
import { Routines } from './screens/Routines';
import { RoutineDetail } from './screens/RoutineDetail';
import { RoutineEditor } from './screens/RoutineEditor';
import { ActiveTraining } from './screens/ActiveTraining';
import { Progress } from './screens/Progress';
import { Profile } from './screens/Profile';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: 'explore', Component: Explore },
      { path: 'exercise/:id', Component: ExerciseDetail },
      { path: 'routines', Component: Routines },
      { path: 'routine/:id', Component: RoutineDetail },
      { path: 'routine/:id/edit', Component: RoutineEditor },
      { path: 'routine/new', Component: RoutineEditor },
      { path: 'training/:id', Component: ActiveTraining },
      { path: 'progress', Component: Progress },
      { path: 'profile', Component: Profile }
    ]
  }
]);
